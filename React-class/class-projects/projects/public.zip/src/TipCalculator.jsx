import React from "react";

function TipCalculator() {
  return (
    <div className="w-screen h-screen flex-col bg-green-200 flex justify-center items-center font-mono">
      <h1 className="mb-5 text-3xl font-mono">Tip Calculator</h1>
      <main className="w-4/5 h-3/6 bg-white p-4 flex gap-2">
        <div className="w-3/6 p-4 grid gap-1">
          <h3 className="bg-white">Bill</h3>
          <div className="bg-white">
            <input
              type="number"
              name="bill"
              placeholder="0.00"
              aria-label="Bill Amount"
              min="0"
              max="10000.00"
              step="0.00"
              required=""
              aria-required="true"
              className="bg-gray-200 w-6/12"
            />
          </div>
          <div className="bg-white">
            <h3>Select Tip %</h3>
          </div>
          {/* <div className="grid grid-cols-3 gap-2 bg-slate-500 w-6/12 text-white rounded-md"> */}
          <div className="grid overflow-scroll gap-1 grid-cols-3 bg-zinc-600">
            <Buttons value="5%" />
            <Buttons value="10%" />
            <Buttons value="15%" />
            <Buttons value="25%" />
            <Buttons value="50%" />
            <Buttons>
              <input
                type="text"
                placeholder="Custom"
                className="bg-white text-black"
              />
            </Buttons>
            {/* <button className="size-7 p-6 bg-green-700">10%</button>
              <button className="size-7 p-6 bg-green-700">15%</button>
              <button className="size-7 p-6 bg-green-700">25%</button>
              <button className="size-7 p-6 bg-green-700">50%</button>
              <button className="w-14 p-6 bg-green-700">Custom</button> */}
          </div>
          {/* Number of People */}
          <h3>Number of People</h3>
          <input
            type="number"
            name="bill"
            placeholder="0.00"
            aria-label="Bill Amount"
            min="0"
            max="10000.00"
            step="0.00"
            aria-required="true"
            className="bg-gray-200 w-6/12"
          />
        </div>
        <div className="bg-green-800 w-3/6 relative overflow-hidden text-lime-500 p-5">
          <div className="flex justify-between">
            <div>
              <h3 className="text-white">Tip Amount</h3>
              <p className="text-green-200 text-xs">/ person</p>
            </div>
            <div>$0.00</div>
          </div>
          <div className="flex justify-between">
            <div>
              <h3 className="text-white">Total</h3>
              <p className="text-green-200 text-xs">/ person</p>
            </div>
            <div>$0.00</div>
          </div>
          <button className="absolute bottom-2 left-0 m-1 w-full rounded-sm text-xl bg-white hover:bg-lime-400">
            Reset
          </button>
        </div>
      </main>
    </div>
  );
}
const Buttons = function ({ children, value }) {
  return (
    <>
      <button
        className={`text-white  grid text-center bg-green-700 rounded-md hover:bg-lime-400`}
      >
        {children || value}
      </button>
    </>
  );
};

export default TipCalculator;
