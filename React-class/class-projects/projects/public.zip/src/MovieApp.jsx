import { Routes, Route } from "react-router-dom";
import Header from "./components/MovieApp/Header";
import Navigation from "./components/MovieApp/Navigation";
import Trending from "./pages/MovieAppPages/Trending";
import Movies from "./pages/MovieAppPages/Movies";
import Search from "./pages/MovieAppPages/Search";
import Series from "./pages/MovieAppPages/Series";
import RouteConfig from "./components/MovieApp/RouteConfig";

function MovieApp() {
  return (
    <>
      <Header />
      <div className="min-h-screen bg-gray-600 text-white pt-32 pb-16 ">
        <Routes>
          {<Route path="/movieApp/trending" element={<Trending />} /> && (
              <Route path="/movieApp/movies" element={<Movies />} />
            ) && <Route path="/movieApp/series" element={<Series />} /> && (
              <Route path="/movieApp/search" element={<Search />} />
            )}
        </Routes>
        {/* <Route path="/movie/:id" element={<MovieDetails />} /> */}
      </div>
      <Navigation />
    </>
  );
}

export default MovieApp;
