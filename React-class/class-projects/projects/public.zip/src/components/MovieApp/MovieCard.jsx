import React from "react";

const MovieCard = () => {
  return (
    <div>
      <div className="badge">7.6</div>
      <img src="https://placehold.co/300" alt="" />
      <b className=""> Movie Title</b>
      <div className="">
        <span>Movie</span>
        <span>2024-11-15</span>
      </div>
    </div>
  );
};

export default MovieCard;
