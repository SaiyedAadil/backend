import { IoTrendingDownOutline } from "react-icons/io5";
import { MdLocalMovies } from "react-icons/md";
import { PiFilmStripFill } from "react-icons/pi";
import { IoMdSearch } from "react-icons/io";
import { useState } from "react";
import { Link, useRouteLoaderData } from "react-router-dom";
import React from "react";
const Navigation = () => {
  const btnCls =
    "flex items-center flex-col p-2 text-white cursor-pointer transition-transform ease-linear duration-150 hover:-translate-y-1";

  const [activeTab, setActiveTab] = useState("trending");

  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="flex justify-around bg-[#1976d2] py-2 fixed bottom-0 w-full">
      <button
        className={
          btnCls +
          " " +
          (activeTab === "trending" ? "bg-[#114b85]" : "bg-transparent")
        }
        onClick={() => handleTabClick("trending")}
      >
        <IoTrendingDownOutline className="text-2xl" />
        <Link to="/movieApp/trending">
          <span className="text-xs mt-1">Trending</span>
        </Link>
      </button>
      <button
        className={
          btnCls +
          " " +
          (activeTab === "movies" ? "bg-[#114b85]" : "bg-transparent")
        }
        onClick={() => handleTabClick("movies")}
      >
        <MdLocalMovies className="text-2xl" />
        <Link to="/movieApp/movies">
          <span className="text-xs mt-1">Movies</span>
        </Link>
      </button>
      <button
        className={
          btnCls +
          " " +
          (activeTab === "series" ? "bg-[#114b85]" : "bg-transparent")
        }
        onClick={() => handleTabClick("series")}
      >
        <PiFilmStripFill className="text-2xl" />
        <Link to="/movieApp/series">
          <span className="text-xs mt-1">Series</span>
        </Link>
      </button>
      <button
        className={
          btnCls +
          " " +
          (activeTab === "search" ? "bg-[#114b85]" : "bg-transparent")
        }
        onClick={() => handleTabClick("search")}
      >
        <IoMdSearch className="text-2xl" />
        <Link to="/movieApp/search">
          <span className="text-xs mt-1">Search</span>
        </Link>
      </button>
    </div>
  );
};

export default Navigation;
