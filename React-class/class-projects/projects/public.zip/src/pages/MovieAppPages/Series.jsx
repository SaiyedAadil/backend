import React from "react";

const Series = () => {
  return <div>Series</div>;
};

export default Series;
