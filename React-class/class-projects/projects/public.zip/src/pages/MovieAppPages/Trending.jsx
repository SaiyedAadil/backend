import React from "react";
import MovieCard from "../../components/MovieApp/MovieCard";

const Trending = () => {
  return (
    <div>
      <span className="uppercase flex justify-center font-serif text-2xl p-1 text-white">
        Trending Today
      </span>
      <section className="flex flex-wrap justify-around ">
        <MovieCard />
      </section>
    </div>
  );
};

export default Trending;
